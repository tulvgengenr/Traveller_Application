package com.example.test3;
/**
 * 使能2.0
 *
 *
 */
public class Data {
    public static boolean fengmingqi = false;
    public static boolean zhaomingdeng = false;
    public static boolean wendujiance = true;
    public static boolean shidujiance = true;
    public static boolean guangqiangjiance = true;
    public static boolean liuzhoujiance = true;
    public static boolean wifi_isopen = false;
    public static boolean lanya = true;
    public static boolean lowpower_isopen = false;
}
