package com.example.test3;
/**
 * deviceID与apiKey
 *
 *
 */
public interface Device {
    //设备id和token
    public static final String deviceId="729910889";
    public static final String apiKey="version=2018-10-31&res=products%2F435187&et=1656209269&method=md5&sign=hpts5sU5mUSYttG5hRpeBA%3D%3D";
    public static final String deviceId_Camera="761565965";
    public static final String apiKey_Camera="version=2018-10-31&res=products%2F447348&et=1656209269&method=md5&sign=U8nk%2FHIz90UNfIviAOng7A%3D%3D";
    public static final String index_front="761565965_1625994000000_";
}