package com.example.test3;
/**
 * 使能1.0
 *
 *
 *
 */
//使能类
public class RBean {
    public int en;      //当前帧
    public int value;   //第几次打开
    public int state;   //状态（是否继续播放）
    public int sum;     //当前视频共有多少帧
    public String time; //本次打开的时间
}
